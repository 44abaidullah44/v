UR TRADER — WEBSITE WITH SERVER-SIDE ADMIN

Features:
- TikTok added with YouTube, WhatsApp, Facebook and Instagram.
- Click the copyright line at the bottom to open Admin Panel.
- Server-side login and session authentication.
- Admin can edit brand/tagline, hero text, About text, social URLs, video titles/links/descriptions, upload logo/profile photo.
- Changes are saved on the server and reflected for all visitors.
- Uploads supported: images and MP4/WEBM videos up to 30 MB (the public page currently uses video links in cards).

Setup:
1. Install Node.js 18+.
2. Extract ZIP and open terminal in the project folder.
3. Run: npm install
4. Set environment variables (do not put secrets in public files):
   ADMIN_PASSWORD=choose-a-strong-password
   SESSION_SECRET=a-long-random-secret
   NODE_ENV=development
5. Run: npm start
6. Visit http://localhost:3000

PowerShell:
$env:ADMIN_PASSWORD="choose-a-strong-password"
$env:SESSION_SECRET="use-a-long-random-secret"
$env:NODE_ENV="development"
npm start

IMPORTANT:
- Set ADMIN_PASSWORD to your preferred password in the hosting environment; it is not hardcoded into browser JavaScript.
- For live hosting, use a Node.js-capable host with persistent disk. Static-only hosting won't run this server/admin API.
- For production set NODE_ENV=production and use HTTPS. Use a long random SESSION_SECRET.
- Back up data/site.json and uploads/ regularly. Some serverless hosts have temporary storage; use a database/object storage for durable multi-instance deployments.
- Since the password was shared in chat, consider changing it before publishing.
